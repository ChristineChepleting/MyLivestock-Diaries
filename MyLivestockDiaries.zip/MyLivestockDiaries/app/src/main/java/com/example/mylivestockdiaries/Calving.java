package com.example.mylivestockdiaries;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Calving extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calving);
    }
}