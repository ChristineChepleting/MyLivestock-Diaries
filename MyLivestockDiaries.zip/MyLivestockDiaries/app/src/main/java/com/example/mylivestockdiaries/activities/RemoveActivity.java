package com.example.mylivestockdiaries.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.mylivestockdiaries.R;

public class RemoveActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remove);
    }
}